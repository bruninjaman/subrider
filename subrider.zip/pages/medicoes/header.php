<!-- Header -->
<header id="header">
    <h1 id="logo">
        <a href="index.php"><img src="./assets/css/images/logo-branco-crop.png" style="height:60px;width:180px;"></a>
    </h1>
    <nav id="nav">
        <ul>
            <li>
                <a class="button primary" href="services.php?ordem=<?php echo $_GET["ordem"]?>">Voltar</a>
            </li>
        </ul>
    </nav>
</header>