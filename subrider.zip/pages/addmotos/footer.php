<!-- Footer -->
<?php
include('includes/footer.php');
?>