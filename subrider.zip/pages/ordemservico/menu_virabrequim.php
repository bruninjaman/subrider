<div class="container">
        <h1>MENU VIRABREQUIM</h1>

        <div class="section">
            <label for="bronzina">BRONZINA:</label>
            <input type="checkbox" id="bronzina">
        </div>

        <div class="section checkbox-container">
            <label for="rolamento">ROLAMENTO:</label>
            <input type="checkbox" id="rolamento">
            <label for="somente-rolamento">Somente para rolamento</label>
            <input type="radio" id="somente-rolamento">
        </div>

        <div class="section">
            <label for="folga_lateral_biela">FOLGA LATERAL BIELA MAX:</label>
            <input type="text" id="folga_lateral_biela" value="0,3"> mm
        </div>

        <div class="section">
            <label for="folga_eixo_bronzina">FOLGA EIXO-BRONZINA MAX:</label>
            <input type="text" id="folga_eixo_bronzina" value="0,080"> mm
        </div>

        <div class="section">
            <label for="folga_eixo_mancal">FOLGA EIXO-MANCAL MAX:</label>
            <input type="text" id="folga_eixo_mancal" value="0,080"> mm
        </div>

        <div class="section">
            <label for="folga_lateral_eixo">FOLGA LATERAL EIXO:</label>
            <input type="text" id="folga_lateral_eixo_min" value="0,050"> a 
            <input type="text" id="folga_lateral_eixo_max" value="0,110"> mm
        </div>

        <div class="section">
            <label for="empenamento_max">EMPENAMENTO MAX:</label>
            <input type="text" id="empenamento_max" value="0,055"> mm
        </div>

        <button class="ok-button">OK</button>
        <div class="back-button">Volta ao Menu ANTERIOR</div>
    </div>