<h2>Informações da Embreagem</h2>
<a class="button secondary" id="backToMenu">Voltar ao Menu</a>