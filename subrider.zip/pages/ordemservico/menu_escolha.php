<h2>Selecione uma Opção</h2>
<a class="button secondary" id="btnCabecote">Cabeçote</a>
<a class="button secondary" id="btnMotor">Motor</a>
<a class="button secondary" id="btnVirabrequim">Virabrequim</a>
<a class="button secondary" id="btnEmbreagem">Embreagem</a>
<a class="button secondary" id="btnBombas">Bombas</a>
<a class="button primary" id="closeModal3">Sair</a>