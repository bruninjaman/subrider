<h2>Menu Cadastro</h2>
<label>Marca: </label>
<input type="text" name="marca">
<label>Modelo: </label>
<input type="text" name="modelo">
<label>Ano: </label>
<input type="text" name="ano">
<a class="button secondary" id="closeModal2">Sair</a>
<a class="button primary" id="next2">OK</a>