<section id="banner">
    <div class="content">
        <center>
            <h2>Não há proprietarios no momento.</h2>
            <a class="button primary" href="#">Adicionar proprietario</a>
        </center>
    </div>
</section>