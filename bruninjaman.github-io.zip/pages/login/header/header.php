<!-- Header -->
<header id="header">
    <h1 id="logo">
        <a href="index.html"><img src="./assets/css/images/logo-branco-crop.png" style="height:60px;width:180px;"></a>
    </h1>
    <nav id="nav">
        <ul>
            <li><a href="index.php">Página Inicial</a></li>
            <li><a class="button secondary" href="index.php">Voltar</a></li>
        </ul>
    </nav>
</header>