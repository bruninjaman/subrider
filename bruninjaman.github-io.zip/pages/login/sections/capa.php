<!-- one -->
<section id="two" class="spotlight style2 right">
    <span class="image fit main"><img src="./assets/css/images/race-moto.gif" alt="" /></span>
    <div class="content">
        <header>
            <h2>Entre na sua conta</h2>
        </header>
        <p>
        <ul>
            <li>
                Página de acesso admnistrativo.
            </li>
            <li>
                Entre em contato pelo whatsapp ou email para contactar-nos
            </li>
        </ul>
        </p>
        <ul class="actions">
            <li><a href="#login" class="button">Entrar</a></li>
        </ul>
    </div>
    <a href="#login" class="goto-next scrolly">Next</a>
</section>