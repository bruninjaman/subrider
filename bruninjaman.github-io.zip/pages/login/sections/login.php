<!-- Two -->
<section id="login" class="spotlight style1 bottom">
    <div class="content">
        <div class="container">
            <div class="row">
                <form id="loginform" name="loginform" method="POST" action="scripts/log-in.php">
                    <div class="col-4 col-12-medium">
                        <h2>Entre com sua conta da sub-rider!</h2>
                        <label for="fname">Login:</label>
                        <input type="text" id="user" name="user" maxlength="25" required><br>
                        <label for="lname">Senha:</label>
                        <input type="password" id="pass" name="pass" maxlength="25" required><br>
                    </div>
                    <div class="col-4 col-12-medium">
                        <a class="button primary" href='javascript:loginform.submit()'>Entrar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>