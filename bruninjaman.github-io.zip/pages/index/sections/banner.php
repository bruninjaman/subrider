<section id="banner">
    <div class="content">
        <header>
            <h2>Mecânica Especializada em motocicletas</h2>
            <p>Oficina multimarcas incluindo HD.<br /> Entre em contato conosco e conheça nossos serviços.</p>
        </header>
        <span class="image"><img src="./assets/css/images/Close.jpg" alt="" /></span>
    </div>
    <a href="#one" class="goto-next scrolly">Proximo</a>
</section>