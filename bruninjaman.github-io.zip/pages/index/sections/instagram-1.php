<section id="three" class="spotlight style3 left">
    <span class="image fit main bottom">
        <img src="./assets/css/images/insta-image.jpg" alt="" />
    </span>
    <div class="content">
        <header>
            <h2>Conheça nosso Instagram</h2>
            <p>Fotos do nosso trabalho.</p>
        </header>
        <p>Nos siga no instagram e fique por dentro de todas novidades.</p>
        <ul class="actions">
            <li><a href="https://www.instagram.com/xandov/" target="_blank" class="button">Seguir</a></li>
        </ul>
    </div>
    <a href="#subriderfeed" class="goto-next scrolly">Proximo</a>
</section>